import { Component } from '@angular/core';

@Component({
  selector: 'app-data-extraction',
  imports: [],
  templateUrl: './data-extraction.component.html',
  styleUrl: './data-extraction.component.css'
})
export class DataExtractionComponent {
  dataHeading:string="Data Extraction"
  
}
